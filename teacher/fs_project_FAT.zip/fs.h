#define	FS_ERROR		-1
#define	FS_SUCCESS		0
#define	FS_FORMATERR	1
